using TaskHub.Application.DTOs;
using TaskHub.Application.Interfaces;
using TaskHub.Domain.Entities;
using TaskHub.Domain.Enums;
using TaskHub.Infrastructure.Repositories;
using System.Text;

namespace TaskHub.Application.Services;

public class TaskService : ITaskService
{
    private readonly TaskRepository _repo;

    public TaskService(TaskRepository repo)
    {
        _repo = repo;
    }

    public IEnumerable<TaskDto> GetAll() =>
        _repo.GetAll().Select(Map);

    public TaskDto? GetById(int id)
    {
        var t = _repo.GetById(id);
        return t == null ? null : Map(t);
    }

    public IEnumerable<TaskDto> GetByUserId(int userId) =>
        _repo.GetByUserId(userId).Select(Map);

    public IEnumerable<TaskDto> Filter(int? userId, TaskStatus? status, TaskPriority? priority, DateTime? dueDateFrom, DateTime? dueDateTo, string? sort, int? page, int? size)
    {
        var query = _repo.GetAll().AsQueryable();
        if (userId.HasValue) query = query.Where(t => t.UserId == userId.Value);
        if (status.HasValue) query = query.Where(t => t.Status == status.Value);
        if (priority.HasValue) query = query.Where(t => t.Priority == priority.Value);
        if (dueDateFrom.HasValue) query = query.Where(t => t.DueDate >= dueDateFrom.Value);
        if (dueDateTo.HasValue) query = query.Where(t => t.DueDate <= dueDateTo.Value);

        if (!string.IsNullOrWhiteSpace(sort))
        {
            switch (sort.ToLower())
            {
                case "duedate": query = query.OrderBy(t => t.DueDate); break;
                case "priority": query = query.OrderBy(t => t.Priority); break;
                case "status": query = query.OrderBy(t => t.Status); break;
                default: break;
            }
        }

        if (page.HasValue && size.HasValue)
            query = query.Skip((page.Value - 1) * size.Value).Take(size.Value);

        return query.ToList().Select(Map);
    }

    public TaskDto Create(TaskDto dto)
    {
        var t = new TaskItem(0, dto.Title, dto.Description, dto.Priority, dto.DueDate, dto.UserId);
        var created = _repo.Add(t);
        dto.Id = created.Id;
        return dto;
    }

    public bool Update(int id, TaskDto dto)
    {
        var t = _repo.GetById(id);
        if (t == null) return false;
        t.Update(dto.Title, dto.Description, dto.Priority, dto.DueDate, dto.UserId);
        return _repo.Update(t);
    }

    public bool UpdateStatus(int id, TaskStatus status)
    {
        var t = _repo.GetById(id);
        if (t == null) return false;
        t.UpdateStatus(status);
        return _repo.Update(t);
    }

    public bool Delete(int id) => _repo.Delete(id);

    public byte[] ExportCsv()
    {
        var tasks = _repo.GetAll();
        var sb = new StringBuilder();
        sb.AppendLine("Id,Title,Description,Status,Priority,DueDate,UserId");
        foreach (var t in tasks)
        {
            sb.AppendLine($"{t.Id},{t.Title},{t.Description},{t.Status},{t.Priority},{t.DueDate:u},{t.UserId}");
        }
        return Encoding.UTF8.GetBytes(sb.ToString());
    }

    private TaskDto Map(TaskItem t) => new TaskDto
    {
        Id = t.Id,
        Title = t.Title,
        Description = t.Description,
        Status = t.Status,
        Priority = t.Priority,
        DueDate = t.DueDate,
        UserId = t.UserId
    };
}