using TaskHub.Application.DTOs;
using TaskHub.Application.Interfaces;
using TaskHub.Domain.Entities;
using TaskHub.Infrastructure.Repositories;

namespace TaskHub.Application.Services;

public class UserService : IUserService
{
    private readonly UserRepository _repo;

    public UserService(UserRepository repo)
    {
        _repo = repo;
    }

    public IEnumerable<UserDto> GetAll() =>
        _repo.GetAll().Select(u => new UserDto { Id = u.Id, Name = u.Name, Email = u.Email });

    public UserDto? GetById(int id)
    {
        var u = _repo.GetById(id);
        return u == null ? null : new UserDto { Id = u.Id, Name = u.Name, Email = u.Email };
    }

    public UserDto Create(UserDto dto)
    {
        var user = new User(0, dto.Name, dto.Email);
        var created = _repo.Add(user);
        dto.Id = created.Id;
        return dto;
    }

    public bool Update(int id, UserDto dto)
    {
        var user = _repo.GetById(id);
        if (user == null) return false;
        user.Update(dto.Name, dto.Email);
        return _repo.Update(user);
    }

    public bool Delete(int id) => _repo.Delete(id);
}