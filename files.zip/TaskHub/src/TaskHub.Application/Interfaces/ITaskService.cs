using TaskHub.Application.DTOs;
using TaskHub.Domain.Enums;

namespace TaskHub.Application.Interfaces;

public interface ITaskService
{
    IEnumerable<TaskDto> GetAll();
    TaskDto? GetById(int id);
    IEnumerable<TaskDto> GetByUserId(int userId);
    IEnumerable<TaskDto> Filter(int? userId, TaskStatus? status, TaskPriority? priority, DateTime? dueDateFrom, DateTime? dueDateTo, string? sort, int? page, int? size);
    TaskDto Create(TaskDto dto);
    bool Update(int id, TaskDto dto);
    bool UpdateStatus(int id, TaskStatus status);
    bool Delete(int id);
    byte[] ExportCsv();
}