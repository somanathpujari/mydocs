using TaskHub.Application.DTOs;

namespace TaskHub.Application.Interfaces;

public interface IUserService
{
    IEnumerable<UserDto> GetAll();
    UserDto? GetById(int id);
    UserDto Create(UserDto dto);
    bool Update(int id, UserDto dto);
    bool Delete(int id);
}