using Microsoft.AspNetCore.Mvc;
using TaskHub.Application.DTOs;
using TaskHub.Application.Interfaces;
using TaskHub.Domain.Enums;

namespace TaskHub.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class TasksController : ControllerBase
{
    private readonly ITaskService _service;
    public TasksController(ITaskService service) => _service = service;

    [HttpGet]
    public IActionResult GetAll([FromQuery] int? userId, [FromQuery] TaskStatus? status, [FromQuery] TaskPriority? priority, [FromQuery] DateTime? dueDateFrom, [FromQuery] DateTime? dueDateTo, [FromQuery] string? sort, [FromQuery] int? page, [FromQuery] int? size)
    {
        var items = _service.Filter(userId, status, priority, dueDateFrom, dueDateTo, sort, page, size);
        return Ok(items);
    }

    [HttpGet("{id}")]
    public IActionResult GetById(int id)
    {
        var t = _service.GetById(id);
        return t == null ? NotFound() : Ok(t);
    }

    [HttpGet("user/{userId}")]
    public IActionResult GetByUserId(int userId) => Ok(_service.GetByUserId(userId));

    [HttpPost]
    public IActionResult Create([FromBody] TaskDto dto) => Ok(_service.Create(dto));

    [HttpPut("{id}")]
    public IActionResult Update(int id, [FromBody] TaskDto dto)
    {
        var ok = _service.Update(id, dto);
        return ok ? NoContent() : NotFound();
    }

    [HttpPatch("{id}/status")]
    public IActionResult UpdateStatus(int id, [FromBody] TaskStatus status)
    {
        var ok = _service.UpdateStatus(id, status);
        return ok ? NoContent() : NotFound();
    }

    [HttpDelete("{id}")]
    public IActionResult Delete(int id)
    {
        var ok = _service.Delete(id);
        return ok ? NoContent() : NotFound();
    }

    [HttpGet("export/csv")]
    public IActionResult ExportCsv()
    {
        var bytes = _service.ExportCsv();
        return File(bytes, "text/csv", "tasks.csv");
    }
}