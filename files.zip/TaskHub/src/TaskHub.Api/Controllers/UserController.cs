using Microsoft.AspNetCore.Mvc;
using TaskHub.Application.DTOs;
using TaskHub.Application.Interfaces;

namespace TaskHub.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class UsersController : ControllerBase
{
    private readonly IUserService _service;
    public UsersController(IUserService service) => _service = service;

    [HttpGet]
    public IActionResult GetAll() => Ok(_service.GetAll());

    [HttpGet("{id}")]
    public IActionResult GetById(int id)
    {
        var u = _service.GetById(id);
        return u == null ? NotFound() : Ok(u);
    }

    [HttpPost]
    public IActionResult Create([FromBody] UserDto dto) => Ok(_service.Create(dto));

    [HttpPut("{id}")]
    public IActionResult Update(int id, [FromBody] UserDto dto)
    {
        var ok = _service.Update(id, dto);
        return ok ? NoContent() : NotFound();
    }

    [HttpDelete("{id}")]
    public IActionResult Delete(int id)
    {
        var ok = _service.Delete(id);
        return ok ? NoContent() : NotFound();
    }
}