using TaskHub.Domain.Entities;

namespace TaskHub.Infrastructure.Repositories;

public class UserRepository
{
    private static readonly List<User> _users = new();
    private static int _nextId = 1;

    public IEnumerable<User> GetAll() => _users;

    public User? GetById(int id) => _users.FirstOrDefault(u => u.Id == id);

    public User Add(User user)
    {
        user.GetType().GetProperty("Id")?.SetValue(user, _nextId++);
        _users.Add(user);
        return user;
    }

    public bool Update(User user)
    {
        var idx = _users.FindIndex(u => u.Id == user.Id);
        if (idx == -1) return false;
        _users[idx] = user;
        return true;
    }

    public bool Delete(int id)
    {
        var u = GetById(id);
        if (u == null) return false;
        _users.Remove(u);
        return true;
    }
}