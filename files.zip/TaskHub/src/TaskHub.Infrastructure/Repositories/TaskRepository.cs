using TaskHub.Domain.Entities;

namespace TaskHub.Infrastructure.Repositories;

public class TaskRepository
{
    private static readonly List<TaskItem> _tasks = new();
    private static int _nextId = 1;

    public IEnumerable<TaskItem> GetAll() => _tasks;

    public TaskItem? GetById(int id) => _tasks.FirstOrDefault(t => t.Id == id);

    public IEnumerable<TaskItem> GetByUserId(int userId) => _tasks.Where(t => t.UserId == userId);

    public TaskItem Add(TaskItem task)
    {
        task.GetType().GetProperty("Id")?.SetValue(task, _nextId++);
        _tasks.Add(task);
        return task;
    }

    public bool Update(TaskItem task)
    {
        var idx = _tasks.FindIndex(t => t.Id == task.Id);
        if (idx == -1) return false;
        _tasks[idx] = task;
        return true;
    }

    public bool Delete(int id)
    {
        var t = GetById(id);
        if (t == null) return false;
        _tasks.Remove(t);
        return true;
    }
}