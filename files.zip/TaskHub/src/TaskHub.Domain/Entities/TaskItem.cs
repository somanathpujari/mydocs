using TaskHub.Domain.Enums;

namespace TaskHub.Domain.Entities;

public class TaskItem
{
    public int Id { get; private set; }
    public string Title { get; private set; } = string.Empty;
    public string Description { get; private set; } = string.Empty;
    public TaskStatus Status { get; private set; }
    public TaskPriority Priority { get; private set; }
    public DateTime DueDate { get; private set; }
    public int UserId { get; private set; }

    public TaskItem(int id, string title, string description, TaskPriority priority, DateTime dueDate, int userId)
    {
        Id = id;
        Update(title, description, priority, dueDate, userId);
        Status = TaskStatus.Pending;
    }

    public void Update(string title, string description, TaskPriority priority, DateTime dueDate, int userId)
    {
        if (string.IsNullOrWhiteSpace(title)) throw new ArgumentException("Title is required");
        if (dueDate <= DateTime.UtcNow) throw new ArgumentException("Due date must be in the future");
        Title = title.Trim();
        Description = description?.Trim() ?? string.Empty;
        Priority = priority;
        DueDate = DateTime.SpecifyKind(dueDate, DateTimeKind.Utc);
        UserId = userId;
    }

    public void UpdateStatus(TaskStatus newStatus)
    {
        if (newStatus < Status) throw new InvalidOperationException("Cannot revert status");
        if (Status == TaskStatus.Pending && newStatus == TaskStatus.Completed)
            throw new InvalidOperationException("Must go through InProgress before Completed");

        Status = newStatus;
    }
}